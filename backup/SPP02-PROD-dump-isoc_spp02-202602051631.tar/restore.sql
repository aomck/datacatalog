--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.20 (Ubuntu 14.20-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE isoc_spp02;
--
-- Name: isoc_spp02; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE isoc_spp02 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


\unrestrict (null)
\connect isoc_spp02
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: isoc_spp02; Type: DATABASE PROPERTIES; Schema: -; Owner: -
--

ALTER DATABASE isoc_spp02 SET search_path TO '$user', 'public', 'topology';


\unrestrict (null)
\connect isoc_spp02
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: masterdata; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA masterdata;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA topology;


--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: get_border_unit_summary(integer, integer); Type: FUNCTION; Schema: masterdata; Owner: -
--

CREATE FUNCTION masterdata.get_border_unit_summary(p_year integer DEFAULT NULL::integer, p_month integer DEFAULT NULL::integer) RETURNS TABLE(unit_name text, region text, sub_region text, report_count bigint, checkpoint_count bigint, patrol_count bigint, intelligence_count bigint, total_prevention numeric, total_illegal_immigrants numeric, total_facilitators numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    WITH border_unit AS (
        SELECT
            ba.report_id,
            ba.prevention_type,
            ba.prevention_count,
            ba.illegal_immigrant_total,
            ba.facilitator_total,
            ba.created_at,
            re.user_id,
            u.organization_type,
            u.region,
            u.sub_region
        FROM public.immigration_border_area AS ba
        LEFT JOIN public.reports AS re
            ON re.id = ba.report_id
        LEFT JOIN public.users AS u
            ON u.id = re.user_id
        WHERE u.organization_type = 'กอ.รมน.ภาค'
          AND ba.created_at IS NOT NULL
          AND (
                -- กรณีไม่ใส่ปีเลย -> ดึงทุกช่วงเวลา
                p_year IS NULL
                OR
                -- กรณีใส่ p_year (และอาจจะใส่/ไม่ใส่ p_month)
                ba.created_at < (
                    CASE
                        -- ถ้าใส่ปี แต่ไม่ใส่เดือน -> ใช้สิ้นปีนั้นเป็นจุดตัด
                        WHEN p_month IS NULL THEN
                            make_date(p_year + 1, 1, 1)::timestamp
                            -- = ดึงตั้งแต่ต้นระบบจนถึง 31 ธ.ค. ปี p_year
                        ELSE
                            -- ถ้าใส่ปีและเดือน -> ใช้ต้นเดือนถัดไปเป็นจุดตัด
                            (make_date(p_year, p_month, 1) + INTERVAL '1 month')::timestamp
                            -- = ดึงตั้งแต่ต้นระบบจนถึงสิ้นเดือน p_month ปี p_year
                    END
                )
              )
    )
    SELECT
        ('กร.รมน.' || b.region || ' ' || b.sub_region)::TEXT AS unit_name,
        b.region::TEXT       AS region,
        b.sub_region::TEXT   AS sub_region,
        COUNT(b.report_id)   AS report_count,

        COUNT(CASE WHEN b.prevention_type = 'checkpoint'   THEN b.report_id END) AS checkpoint_count,
        COUNT(CASE WHEN b.prevention_type = 'patrol'       THEN b.report_id END) AS patrol_count,
        COUNT(CASE WHEN b.prevention_type = 'intelligence' THEN b.report_id END) AS intelligence_count,

        SUM(b.prevention_count)::NUMERIC         AS total_prevention,
        SUM(b.illegal_immigrant_total)::NUMERIC AS total_illegal_immigrants,
        SUM(b.facilitator_total)::NUMERIC       AS total_facilitators
    FROM border_unit AS b
    GROUP BY
        b.region,
        b.sub_region
    ORDER BY
        unit_name;
END;
$$;


--
-- Name: get_inner_unit_summary(integer, integer); Type: FUNCTION; Schema: masterdata; Owner: -
--

CREATE FUNCTION masterdata.get_inner_unit_summary(p_year integer DEFAULT NULL::integer, p_month integer DEFAULT NULL::integer) RETURNS TABLE(organization_type text, province_unit text, province_code text, report_count bigint, inspected_persons_total numeric, immigration_invalid_total numeric, inspected_accommodations_count bigint, num_target numeric, inspected_accommodations_ratio_pct numeric, status text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- กันเคสใส่เดือนแต่ไม่ใส่ปี (จะงงทีหลัง)
    IF p_year IS NULL AND p_month IS NOT NULL THEN
        RAISE EXCEPTION 'If p_month is not null, p_year must not be null';
    END IF;

    RETURN QUERY
    WITH unit_summary AS (
        SELECT
            ba.report_id,
            ba.grand_total,
            ba.immigration_invalid_male,
            ba.immigration_invalid_female,
            ba.created_at,
            re.user_id,
            u.organization_type,
            u.region,
            u.province_unit,
            ii.province_code,
            -- indicator เป็น varchar → cast เป็น NUMERIC
            ii.indicator::NUMERIC AS ind
        FROM public.immigration_inner_area AS ba
        LEFT JOIN public.reports AS re
            ON re.id = ba.report_id
        LEFT JOIN public.users AS u
            ON u.id = re.user_id
        LEFT JOIN masterdata.inner_indicator AS ii
            ON u.province_unit::TEXT = ii.province_name::TEXT
        WHERE u.organization_type = 'กอ.รมน.จังหวัด'
          AND ba.created_at IS NOT NULL
          AND (
                -- ไม่ใส่ปี -> ดึงทั้งหมด (สะสม)
                p_year IS NULL
                OR
                -- ใส่ปี (และอาจใส่/ไม่ใส่เดือน) -> ใช้ created_at < end_date
                ba.created_at < (
                    CASE
                        -- ใส่ปีแต่ไม่ใส่เดือน -> ดึงจนถึงสิ้นปี p_year
                        WHEN p_month IS NULL THEN
                            make_date(p_year + 1, 1, 1)::timestamp
                        -- ใส่ปีและเดือน -> ดึงจนถึงสิ้นเดือน p_month ปี p_year
                        ELSE
                            (make_date(p_year, p_month, 1) + INTERVAL '1 month')::timestamp
                    END
                )
          )
    )
    SELECT
        us.organization_type::TEXT                             AS organization_type,
        us.province_unit::TEXT                                 AS province_unit,
        us.province_code::TEXT                                 AS province_code,
        COUNT(us.report_id)                                    AS report_count,
        SUM(COALESCE(us.grand_total, 0))::NUMERIC              AS inspected_persons_total,
        SUM(
            COALESCE(us.immigration_invalid_male, 0)
          + COALESCE(us.immigration_invalid_female, 0)
        )::NUMERIC                                             AS immigration_invalid_total,
        COUNT(us.report_id)::BIGINT                            AS inspected_accommodations_count,
        us.ind                                                 AS num_target,
        ROUND(
            COUNT(us.report_id)::NUMERIC / NULLIF(us.ind, 0) * 100,
            2
        )                                                      AS inspected_accommodations_ratio_pct,
        CASE
            WHEN COUNT(us.report_id)::NUMERIC / NULLIF(us.ind, 0) * 100 >= 100
                THEN 'ผ่าน'
            ELSE 'ไม่ผ่าน'
        END                                                    AS status
    FROM unit_summary AS us
    GROUP BY
        us.organization_type,
        us.province_unit,
        us.province_code,
        us.ind
    ORDER BY
        us.province_unit;
END;
$$;


--
-- Name: get_main_indicator_form_report_by_year(character varying, integer); Type: FUNCTION; Schema: masterdata; Owner: -
--

CREATE FUNCTION masterdata.get_main_indicator_form_report_by_year(p_form_type character varying, p_year integer DEFAULT (EXTRACT(year FROM CURRENT_DATE))::integer) RETURNS TABLE(form_type text, year integer, report_count bigint, indicator_ratio numeric, indicator_target numeric, status text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_raw_indicator NUMERIC := 0;  -- ค่า ratio ที่คำนวณได้ (อาจเกิน 100)
    v_report_count  BIGINT  := 0;  -- COUNT(id)
BEGIN
    -- =======================
    -- inner
    -- =======================
    IF p_form_type = 'inner' THEN

        SELECT
            COALESCE(COUNT(id), 0)                                        AS report_count,
            COALESCE(COUNT(id)::NUMERIC / 10, 0)                          AS indicator_ratio_raw
        INTO
            v_report_count,
            v_raw_indicator
        FROM public.immigration_inner_area
        WHERE created_at IS NOT NULL
          AND EXTRACT(YEAR FROM created_at) <= p_year;

    -- =======================
    -- border
    -- =======================
    ELSIF p_form_type = 'border' THEN

        SELECT
            COALESCE(COUNT(id), 0)                                        AS report_count,
            COALESCE(
                (
                    COALESCE(SUM(illegal_immigrant_total), 0)::NUMERIC
                  + COALESCE(SUM(facilitator_total), 0)::NUMERIC
                ) / 10
            , 0)                                                          AS indicator_ratio_raw
        INTO
            v_report_count,
            v_raw_indicator
        FROM public.immigration_border_area
        WHERE created_at IS NOT NULL
          AND EXTRACT(YEAR FROM created_at) <= p_year;

    -- =======================
    -- clergy
    -- =======================
    ELSIF p_form_type = 'Clergy' THEN
        v_report_count  := 0;
        v_raw_indicator := 0;

    ELSE
        RAISE EXCEPTION 'Invalid form_type: %, use inner, border, or Clergy', p_form_type;
    END IF;

    -- คืนค่าเป็นตาราง 1 แถว
    RETURN QUERY
    SELECT
        p_form_type::TEXT           AS form_type,
        p_year::INT                 AS year,
        v_report_count              AS report_count,
        LEAST(v_raw_indicator, 100) AS indicator_ratio,   -- ไม่เกิน 100
        1000::NUMERIC               AS indicator_target,  -- ค่าคงที่ 1000
        CASE
            WHEN v_raw_indicator >= 100 THEN 'ผ่าน'
            ELSE 'ไม่ผ่าน'
        END                        AS status;

END;
$$;


--
-- Name: get_report_file_urls(uuid); Type: FUNCTION; Schema: masterdata; Owner: -
--

CREATE FUNCTION masterdata.get_report_file_urls(p_report_id uuid) RETURNS TABLE(file_url text)
    LANGUAGE sql
    AS $$
    SELECT rf.file_url
    FROM public.report_files AS rf
    WHERE rf.report_id = p_report_id
    ORDER BY rf.uploaded_at;
$$;


--
-- Name: sync_reports_from_immi(); Type: FUNCTION; Schema: masterdata; Owner: -
--

CREATE FUNCTION masterdata.sync_reports_from_immi() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE reports r
    SET address = NEW.accommodation_name ,
		province_code = NEW.accommodation_province_code ,
    	district_code = New.accommodation_district_code ,
    	subdistrict_code = New.accommodation_subdistrict_code
    WHERE r.id = NEW.report_id;

    RETURN NEW;
END;
$$;


--
-- Name: get_border_unit_summary(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_border_unit_summary(p_year integer DEFAULT NULL::integer, p_month integer DEFAULT NULL::integer) RETURNS TABLE(unit_name text, region text, sub_region text, report_count bigint, checkpoint_count bigint, patrol_count bigint, intelligence_count bigint, total_prevention numeric, total_illegal_immigrants numeric, total_facilitators numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    WITH border_unit AS (
        SELECT
            ba.report_id,
            ba.prevention_type,
            ba.prevention_count,
            ba.illegal_immigrant_total,
            ba.facilitator_total,
            ba.created_at,
            re.user_id,
            u.organization_type,
            u.region,
            u.sub_region
        FROM public.immigration_border_area AS ba
        LEFT JOIN public.reports AS re
            ON re.id = ba.report_id
        LEFT JOIN public.users AS u
            ON u.id = re.user_id
        WHERE u.organization_type = 'กอ.รมน.ภาค'
          AND ba.created_at IS NOT NULL
          AND (
                -- กรณีไม่ใส่ปีเลย -> ดึงทุกช่วงเวลา
                p_year IS NULL
                OR
                -- กรณีใส่ p_year (และอาจจะใส่/ไม่ใส่ p_month)
                ba.created_at < (
                    CASE
                        -- ถ้าใส่ปี แต่ไม่ใส่เดือน -> ใช้สิ้นปีนั้นเป็นจุดตัด
                        WHEN p_month IS NULL THEN
                            make_date(p_year + 1, 1, 1)::timestamp
                            -- = ดึงตั้งแต่ต้นระบบจนถึง 31 ธ.ค. ปี p_year
                        ELSE
                            -- ถ้าใส่ปีและเดือน -> ใช้ต้นเดือนถัดไปเป็นจุดตัด
                            (make_date(p_year, p_month, 1) + INTERVAL '1 month')::timestamp
                            -- = ดึงตั้งแต่ต้นระบบจนถึงสิ้นเดือน p_month ปี p_year
                    END
                )
              )
    )
    SELECT
        ('กร.รมน.' || b.region || ' ' || b.sub_region)::TEXT AS unit_name,
        b.region::TEXT       AS region,
        b.sub_region::TEXT   AS sub_region,
        COUNT(b.report_id)   AS report_count,

        COUNT(CASE WHEN b.prevention_type = 'checkpoint'   THEN b.report_id END) AS checkpoint_count,
        COUNT(CASE WHEN b.prevention_type = 'patrol'       THEN b.report_id END) AS patrol_count,
        COUNT(CASE WHEN b.prevention_type = 'intelligence' THEN b.report_id END) AS intelligence_count,

        SUM(b.prevention_count)::NUMERIC         AS total_prevention,
        SUM(b.illegal_immigrant_total)::NUMERIC AS total_illegal_immigrants,
        SUM(b.facilitator_total)::NUMERIC       AS total_facilitators
    FROM border_unit AS b
    GROUP BY
        b.region,
        b.sub_region
    ORDER BY
        unit_name;
END;
$$;


--
-- Name: get_report_file_urls(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_report_file_urls(p_report_id uuid) RETURNS TABLE(file_url text)
    LANGUAGE sql
    AS $$
    SELECT rf.file_url
    FROM public.report_files AS rf
    WHERE rf.report_id = p_report_id
    ORDER BY rf.uploaded_at;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: thailand_tambon; Type: TABLE; Schema: masterdata; Owner: -
--

CREATE TABLE masterdata.thailand_tambon (
    "ID" integer,
    polytype integer,
    province_code character varying,
    amphoe_id integer,
    tambon_id integer,
    province_th character varying(50),
    province_en character varying(50),
    amphoe_th character varying(50),
    amphoe_en character varying(50),
    tambon_th character varying(50),
    tambon_en character varying(50),
    amphoe_code character varying,
    tambon_code character varying
);


--
-- Name: report_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_files (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    file_url text NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(100),
    file_size integer,
    mime_type character varying(100),
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE report_files; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.report_files IS 'ไฟล์แนบ';


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    issue_type character varying(255) NOT NULL,
    sub_category_1 character varying(255),
    sub_category_2 character varying(255),
    sub_category_3 character varying(255),
    category_path text,
    report_type character varying(100),
    address text,
    province_code character varying(20),
    district_code character varying(20),
    subdistrict_code character varying(20),
    location_description text,
    latitude numeric(10,8),
    longitude numeric(11,8),
    incident_datetime timestamp with time zone,
    consideration text,
    other_results text,
    files_count integer DEFAULT 0,
    liff_id character varying(100),
    reported_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'pending'::character varying
);


--
-- Name: TABLE reports; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.reports IS 'รายงานสถานการณ์';


--
-- Name: trafficking_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trafficking_details (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    training_round character varying(100),
    children integer DEFAULT 0,
    youth integer DEFAULT 0,
    working_age integer DEFAULT 0,
    elderly integer DEFAULT 0,
    total integer GENERATED ALWAYS AS ((((children + youth) + working_age) + elderly)) STORED,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE trafficking_details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.trafficking_details IS 'ข้อมูลการอบรมป้องกันการค้ามนุษย์ (แบ่งตามกลุ่มอายุ)';


--
-- Name: COLUMN trafficking_details.children; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trafficking_details.children IS '👶 กลุ่มเด็ก (อายุต่ำกว่า 18 ปี)';


--
-- Name: COLUMN trafficking_details.youth; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trafficking_details.youth IS '🧑 กลุ่มเยาวชน (18-25 ปี)';


--
-- Name: COLUMN trafficking_details.working_age; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trafficking_details.working_age IS '💼 กลุ่มวัยแรงงาน (26-59 ปี)';


--
-- Name: COLUMN trafficking_details.elderly; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trafficking_details.elderly IS '👴 กลุ่มผู้สูงอายุ (60 ปีขึ้นไป)';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    line_user_id character varying(255) NOT NULL,
    line_display_name character varying(255),
    line_picture_url text,
    line_status_message text,
    full_name character varying(255) NOT NULL,
    rank character varying(100),
    "position" character varying(255),
    phone_number character varying(20) NOT NULL,
    line_id character varying(100) NOT NULL,
    organization_type character varying(100) NOT NULL,
    region character varying(100),
    sub_region character varying(100),
    unit_code character varying(50),
    province_unit character varying(100),
    full_unit_path text,
    province_code character varying(20),
    district_code character varying(20),
    subdistrict_code character varying(20),
    photo_url text,
    photo_size integer,
    photo_type character varying(50),
    photo_name character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying,
    approved_by character varying(255),
    approved_at timestamp with time zone,
    rejected_by character varying(255),
    rejected_at timestamp with time zone,
    rejected_reason text,
    liff_id character varying(100),
    registered_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true,
    last_login_at timestamp with time zone,
    CONSTRAINT users_phone_check CHECK (((phone_number)::text ~ '^[0-9]{9,10}$'::text)),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'ผู้ใช้งานระบบ';


--
-- Name: human_trafficking_training; Type: VIEW; Schema: masterdata; Owner: -
--

CREATE VIEW masterdata.human_trafficking_training AS
 SELECT re.id AS report_id,
    re.user_id,
    re.issue_type,
    re.sub_category_1,
    re.sub_category_2,
    re.sub_category_3,
    re.category_path,
    re.report_type,
    re.address,
    re.province_code,
    re.district_code AS amphoe_code,
    re.subdistrict_code AS tambon_code,
    re.latitude,
    re.longitude,
    re.incident_datetime,
    re.consideration,
    re.other_results,
    re.files_count,
    re.liff_id,
    re.reported_at,
    re.updated_at,
    re.status AS report_status,
    rf.file_url,
    rf.file_name,
    rf.file_type,
    rf.mime_type,
    td.training_round,
    td.children,
    td.youth,
    td.working_age,
    td.elderly,
    td.total,
    ur.line_user_id,
    ur.full_name,
    ur.rank,
    ur."position",
    ur.organization_type,
    ur.region,
    ur.sub_region,
    ur.unit_code,
    ur.province_unit,
    ur.full_unit_path,
    mtt.province_th,
    mtt.amphoe_th,
    mtt.tambon_th
   FROM ((((public.reports re
     LEFT JOIN public.report_files rf ON ((re.id = rf.report_id)))
     LEFT JOIN public.trafficking_details td ON ((re.id = td.report_id)))
     LEFT JOIN public.users ur ON ((re.user_id = ur.id)))
     LEFT JOIN masterdata.thailand_tambon mtt ON (((re.subdistrict_code)::text = (mtt.tambon_code)::text)))
  WHERE ((re.issue_type)::text = 'โครงการป้องกันและแก้ไขปัญหาการค้ามนุษย์'::text);


--
-- Name: immigration_border_area; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.immigration_border_area (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    prevention_type character varying(100),
    prevention_count integer DEFAULT 0,
    prevention_remark text,
    illegal_immigrant_male integer DEFAULT 0,
    illegal_immigrant_female integer DEFAULT 0,
    illegal_immigrant_total integer GENERATED ALWAYS AS ((illegal_immigrant_male + illegal_immigrant_female)) STORED,
    illegal_immigrant_remark text,
    facilitator_male integer DEFAULT 0,
    facilitator_female integer DEFAULT 0,
    facilitator_total integer GENERATED ALWAYS AS ((facilitator_male + facilitator_female)) STORED,
    facilitator_remark text,
    illegal_immigrant_nationalities jsonb DEFAULT '[]'::jsonb,
    illegal_immigrant_nationality_total integer DEFAULT 0,
    facilitator_nationalities jsonb DEFAULT '[]'::jsonb,
    facilitator_nationality_total integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE immigration_border_area; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.immigration_border_area IS 'ข้อมูลผู้เข้าเมือง - พื้นที่ชายแดน';


--
-- Name: immigrant_border_reports; Type: VIEW; Schema: masterdata; Owner: -
--

CREATE VIEW masterdata.immigrant_border_reports AS
 SELECT re.id AS report_id,
    re.user_id,
    re.issue_type,
    re.sub_category_1,
    re.sub_category_2,
    re.sub_category_3,
    re.category_path,
    re.report_type,
    re.address,
    re.province_code,
    re.district_code AS amphoe_code,
    re.subdistrict_code AS tambon_code,
    re.latitude,
    re.longitude,
    re.incident_datetime,
    re.consideration,
    re.other_results,
    re.files_count,
    re.liff_id,
    re.reported_at,
    re.updated_at,
    re.status AS report_status,
    iba.prevention_type,
    iba.prevention_count,
    iba.prevention_remark,
    iba.illegal_immigrant_male,
    iba.illegal_immigrant_female,
    iba.illegal_immigrant_total,
    iba.illegal_immigrant_remark,
    iba.facilitator_male,
    iba.facilitator_female,
    iba.facilitator_total,
    iba.facilitator_remark,
    iba.illegal_immigrant_nationalities,
    iba.illegal_immigrant_nationality_total,
    iba.facilitator_nationalities,
    iba.facilitator_nationality_total,
    ur.line_user_id,
    ur.full_name,
    ur.rank,
    ur."position",
    ur.organization_type,
    ur.region,
    ur.sub_region,
    ur.unit_code,
    ur.province_unit,
    ur.full_unit_path,
    mtt.province_th,
    mtt.amphoe_th,
    mtt.tambon_th
   FROM (((public.reports re
     LEFT JOIN public.immigration_border_area iba ON ((re.id = iba.report_id)))
     LEFT JOIN public.users ur ON ((re.user_id = ur.id)))
     LEFT JOIN masterdata.thailand_tambon mtt ON (((re.subdistrict_code)::text = (mtt.tambon_code)::text)))
  WHERE ((re.sub_category_2)::text = 'พื้นที่ชายแดน'::text);


--
-- Name: immigration_inner_area; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.immigration_inner_area (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    total_male integer DEFAULT 0,
    total_female integer DEFAULT 0,
    grand_total integer GENERATED ALWAYS AS ((total_male + total_female)) STORED,
    nationalities jsonb DEFAULT '[]'::jsonb,
    nationality_total integer DEFAULT 0,
    age_ranges jsonb DEFAULT '[]'::jsonb,
    age_total integer DEFAULT 0,
    permit_valid_male integer DEFAULT 0,
    permit_valid_female integer DEFAULT 0,
    permit_invalid_male integer DEFAULT 0,
    permit_invalid_female integer DEFAULT 0,
    permit_total integer GENERATED ALWAYS AS ((((permit_valid_male + permit_valid_female) + permit_invalid_male) + permit_invalid_female)) STORED,
    immigration_valid_male integer DEFAULT 0,
    immigration_valid_female integer DEFAULT 0,
    immigration_invalid_male integer DEFAULT 0,
    immigration_invalid_female integer DEFAULT 0,
    immigration_status_total integer GENERATED ALWAYS AS ((((immigration_valid_male + immigration_valid_female) + immigration_invalid_male) + immigration_invalid_female)) STORED,
    accommodation_name character varying(255),
    accommodation_number character varying(100),
    accommodation_province_code character varying(20),
    accommodation_district_code character varying(20),
    accommodation_subdistrict_code character varying(20),
    accommodation_location character varying(255),
    accommodation_latitude numeric(10,8),
    accommodation_longitude numeric(11,8),
    accommodation_datetime timestamp with time zone,
    room_type jsonb DEFAULT '{}'::jsonb,
    bathroom_count integer DEFAULT 0,
    bathroom_status character varying(50),
    environment_status character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE immigration_inner_area; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.immigration_inner_area IS 'ข้อมูลผู้เข้าเมือง - พื้นที่ตอนใน (ตรวจที่พัก + ข้อมูลที่พัก)';


--
-- Name: immigrant_inner_reports; Type: VIEW; Schema: masterdata; Owner: -
--

CREATE VIEW masterdata.immigrant_inner_reports AS
 SELECT re.id AS report_id,
    re.user_id,
    re.issue_type,
    re.sub_category_1,
    re.sub_category_2,
    re.sub_category_3,
    re.category_path,
    re.report_type,
    re.address,
    re.province_code,
    re.district_code AS amphoe_code,
    re.subdistrict_code AS tambon_code,
    re.incident_datetime,
    re.consideration,
    re.other_results,
    re.files_count,
    re.liff_id,
    re.reported_at,
    re.updated_at,
    re.status AS report_status,
    iia.total_male,
    iia.total_female,
    iia.grand_total,
    iia.nationalities,
    iia.nationality_total,
    iia.age_ranges,
    iia.age_total,
    iia.permit_valid_male,
    iia.permit_valid_female,
    iia.permit_invalid_male,
    iia.permit_invalid_female,
    iia.permit_total,
    iia.immigration_valid_male,
    iia.immigration_valid_female,
    iia.immigration_invalid_male,
    iia.immigration_invalid_female,
    iia.immigration_status_total,
    iia.accommodation_name,
    iia.accommodation_number,
    iia.accommodation_province_code,
    iia.accommodation_district_code,
    iia.accommodation_subdistrict_code,
    iia.accommodation_location,
    iia.accommodation_latitude AS latitude,
    iia.accommodation_longitude AS longitude,
    iia.accommodation_datetime,
    iia.room_type,
    iia.bathroom_count,
    iia.bathroom_status,
    iia.environment_status,
    ur.line_user_id,
    ur.full_name,
    ur.rank,
    ur."position",
    ur.organization_type,
    ur.region,
    ur.sub_region,
    ur.unit_code,
    ur.province_unit,
    ur.full_unit_path,
    tt.province_th,
    tt.amphoe_th,
    tt.tambon_th
   FROM (((public.reports re
     LEFT JOIN public.immigration_inner_area iia ON ((re.id = iia.report_id)))
     LEFT JOIN public.users ur ON ((re.user_id = ur.id)))
     LEFT JOIN masterdata.thailand_tambon tt ON (((tt.tambon_code)::text = (re.subdistrict_code)::text)))
  WHERE ((re.sub_category_2)::text = 'พื้นที่ตอนใน'::text);


--
-- Name: inner_indicator; Type: TABLE; Schema: masterdata; Owner: -
--

CREATE TABLE masterdata.inner_indicator (
    province_code integer NOT NULL,
    agency text NOT NULL,
    province_name text NOT NULL,
    indicator numeric(12,2)
);


--
-- Name: thailand_amphoe_gistda; Type: TABLE; Schema: masterdata; Owner: -
--

CREATE TABLE masterdata.thailand_amphoe_gistda (
    amphoe_code integer,
    amphoe_name character varying(50),
    province_code integer,
    province_name character varying(50),
    lat real,
    lng real,
    region_code integer,
    region_name character varying(50),
    _isoc_id character varying(50),
    insert_date character varying(50)
);


--
-- Name: thailand_province_gistda; Type: TABLE; Schema: masterdata; Owner: -
--

CREATE TABLE masterdata.thailand_province_gistda (
    province_code character varying,
    province_name character varying(50),
    country_code character varying(50),
    region_code character varying,
    lat real,
    lng real,
    province_abbr character varying(50),
    region_name character varying(50),
    _isoc_id character varying(50),
    insert_date character varying(50)
);


--
-- Name: line_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    group_id character varying(255) NOT NULL,
    group_name character varying(255),
    added_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_message_at timestamp with time zone,
    is_active boolean DEFAULT true,
    member_count integer DEFAULT 0,
    notification_count integer DEFAULT 0
);


--
-- Name: TABLE line_groups; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.line_groups IS 'กลุ่ม LINE ที่ BOT เข้าร่วม';


--
-- Name: stateless_monks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stateless_monks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_id uuid NOT NULL,
    location_name character varying(255),
    location_number character varying(100),
    location_province_code character varying(20),
    location_district_code character varying(20),
    location_subdistrict_code character varying(20),
    total_male integer DEFAULT 0,
    total_female integer DEFAULT 0,
    grand_total integer GENERATED ALWAYS AS ((total_male + total_female)) STORED,
    age_ranges jsonb DEFAULT '[]'::jsonb,
    age_total integer DEFAULT 0,
    room_type jsonb DEFAULT '{}'::jsonb,
    environment_status character varying(100),
    immigration_valid_male integer DEFAULT 0,
    immigration_valid_female integer DEFAULT 0,
    immigration_invalid_male integer DEFAULT 0,
    immigration_invalid_female integer DEFAULT 0,
    immigration_status_total integer GENERATED ALWAYS AS ((((immigration_valid_male + immigration_valid_female) + immigration_invalid_male) + immigration_invalid_female)) STORED,
    nationalities jsonb DEFAULT '[]'::jsonb,
    nationality_total integer DEFAULT 0,
    residence_no_citizenship_male integer DEFAULT 0,
    residence_no_citizenship_female integer DEFAULT 0,
    residence_no_citizenship_total integer GENERATED ALWAYS AS ((residence_no_citizenship_male + residence_no_citizenship_female)) STORED,
    residence_no_citizenship_remark text,
    stateless_male integer DEFAULT 0,
    stateless_female integer DEFAULT 0,
    stateless_total integer GENERATED ALWAYS AS ((stateless_male + stateless_female)) STORED,
    stateless_remark text,
    civil_status_other_male integer DEFAULT 0,
    civil_status_other_female integer DEFAULT 0,
    civil_status_other_total integer GENERATED ALWAYS AS ((civil_status_other_male + civil_status_other_female)) STORED,
    civil_status_other_remark text,
    buddhist_male integer DEFAULT 0,
    buddhist_female integer DEFAULT 0,
    buddhist_total integer GENERATED ALWAYS AS ((buddhist_male + buddhist_female)) STORED,
    buddhist_remark text,
    islam_male integer DEFAULT 0,
    islam_female integer DEFAULT 0,
    islam_total integer GENERATED ALWAYS AS ((islam_male + islam_female)) STORED,
    islam_remark text,
    christian_male integer DEFAULT 0,
    christian_female integer DEFAULT 0,
    christian_total integer GENERATED ALWAYS AS ((christian_male + christian_female)) STORED,
    christian_remark text,
    hindu_male integer DEFAULT 0,
    hindu_female integer DEFAULT 0,
    hindu_total integer GENERATED ALWAYS AS ((hindu_male + hindu_female)) STORED,
    hindu_remark text,
    judaism_male integer DEFAULT 0,
    judaism_female integer DEFAULT 0,
    judaism_total integer GENERATED ALWAYS AS ((judaism_male + judaism_female)) STORED,
    judaism_remark text,
    jainism_male integer DEFAULT 0,
    jainism_female integer DEFAULT 0,
    jainism_total integer GENERATED ALWAYS AS ((jainism_male + jainism_female)) STORED,
    jainism_remark text,
    sikhism_male integer DEFAULT 0,
    sikhism_female integer DEFAULT 0,
    sikhism_total integer GENERATED ALWAYS AS ((sikhism_male + sikhism_female)) STORED,
    sikhism_remark text,
    taoism_confucianism_male integer DEFAULT 0,
    taoism_confucianism_female integer DEFAULT 0,
    taoism_confucianism_total integer GENERATED ALWAYS AS ((taoism_confucianism_male + taoism_confucianism_female)) STORED,
    taoism_confucianism_remark text,
    religion_other_male integer DEFAULT 0,
    religion_other_female integer DEFAULT 0,
    religion_other_total integer GENERATED ALWAYS AS ((religion_other_male + religion_other_female)) STORED,
    religion_other_remark text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE stateless_monks; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.stateless_monks IS 'กลุ่มนักบวชไร้รัฐไร้สัญชาติ (สถานะทางทะเบียนราษฎรและสังกัดนิกาย)';


--
-- Name: COLUMN stateless_monks.residence_no_citizenship_male; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stateless_monks.residence_no_citizenship_male IS 'บุคคลที่มีถิ่นที่อยู่ในประเทศไทยแต่ไม่มีสัญชาติไทย (ชาย)';


--
-- Name: COLUMN stateless_monks.stateless_male; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stateless_monks.stateless_male IS 'บุคคลที่ไม่มีสถานะทางทะเบียน/บุคคลไร้รัฐ (ชาย)';


--
-- Name: COLUMN stateless_monks.buddhist_male; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stateless_monks.buddhist_male IS 'นับถือศาสนาพุทธ (มหานิกาย, ธรรมยุติกนิกาย, วัชรยาน, มหายาน) (ชาย)';


--
-- Name: COLUMN stateless_monks.islam_male; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stateless_monks.islam_male IS 'นับถือศาสนาอิสลาม (ซุนนี, ชีอะห์) (ชาย)';


--
-- Name: COLUMN stateless_monks.christian_male; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stateless_monks.christian_male IS 'นับถือศาสนาคริสต์ (คาทอลิก, โปรเตสแตนต์) (ชาย)';


--
-- Name: COLUMN stateless_monks.hindu_male; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stateless_monks.hindu_male IS 'นับถือศาสนาฮินดู (ไวษณพ, ไศวะ, ศักติ) (ชาย)';


--
-- Data for Name: inner_indicator; Type: TABLE DATA; Schema: masterdata; Owner: -
--

COPY masterdata.inner_indicator (province_code, agency, province_name, indicator) FROM stdin;
\.
COPY masterdata.inner_indicator (province_code, agency, province_name, indicator) FROM '$$PATH$$/3565.dat';

--
-- Data for Name: thailand_amphoe_gistda; Type: TABLE DATA; Schema: masterdata; Owner: -
--

COPY masterdata.thailand_amphoe_gistda (amphoe_code, amphoe_name, province_code, province_name, lat, lng, region_code, region_name, _isoc_id, insert_date) FROM stdin;
\.
COPY masterdata.thailand_amphoe_gistda (amphoe_code, amphoe_name, province_code, province_name, lat, lng, region_code, region_name, _isoc_id, insert_date) FROM '$$PATH$$/3562.dat';

--
-- Data for Name: thailand_province_gistda; Type: TABLE DATA; Schema: masterdata; Owner: -
--

COPY masterdata.thailand_province_gistda (province_code, province_name, country_code, region_code, lat, lng, province_abbr, region_name, _isoc_id, insert_date) FROM stdin;
\.
COPY masterdata.thailand_province_gistda (province_code, province_name, country_code, region_code, lat, lng, province_abbr, region_name, _isoc_id, insert_date) FROM '$$PATH$$/3563.dat';

--
-- Data for Name: thailand_tambon; Type: TABLE DATA; Schema: masterdata; Owner: -
--

COPY masterdata.thailand_tambon ("ID", polytype, province_code, amphoe_id, tambon_id, province_th, province_en, amphoe_th, amphoe_en, tambon_th, tambon_en, amphoe_code, tambon_code) FROM stdin;
\.
COPY masterdata.thailand_tambon ("ID", polytype, province_code, amphoe_id, tambon_id, province_th, province_en, amphoe_th, amphoe_en, tambon_th, tambon_en, amphoe_code, tambon_code) FROM '$$PATH$$/3564.dat';

--
-- Data for Name: immigration_border_area; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.immigration_border_area (id, report_id, prevention_type, prevention_count, prevention_remark, illegal_immigrant_male, illegal_immigrant_female, illegal_immigrant_remark, facilitator_male, facilitator_female, facilitator_remark, illegal_immigrant_nationalities, illegal_immigrant_nationality_total, facilitator_nationalities, facilitator_nationality_total, created_at, updated_at) FROM stdin;
\.
COPY public.immigration_border_area (id, report_id, prevention_type, prevention_count, prevention_remark, illegal_immigrant_male, illegal_immigrant_female, illegal_immigrant_remark, facilitator_male, facilitator_female, facilitator_remark, illegal_immigrant_nationalities, illegal_immigrant_nationality_total, facilitator_nationalities, facilitator_nationality_total, created_at, updated_at) FROM '$$PATH$$/3570.dat';

--
-- Data for Name: immigration_inner_area; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.immigration_inner_area (id, report_id, total_male, total_female, nationalities, nationality_total, age_ranges, age_total, permit_valid_male, permit_valid_female, permit_invalid_male, permit_invalid_female, immigration_valid_male, immigration_valid_female, immigration_invalid_male, immigration_invalid_female, accommodation_name, accommodation_number, accommodation_province_code, accommodation_district_code, accommodation_subdistrict_code, accommodation_location, accommodation_latitude, accommodation_longitude, accommodation_datetime, room_type, bathroom_count, bathroom_status, environment_status, created_at, updated_at) FROM stdin;
\.
COPY public.immigration_inner_area (id, report_id, total_male, total_female, nationalities, nationality_total, age_ranges, age_total, permit_valid_male, permit_valid_female, permit_invalid_male, permit_invalid_female, immigration_valid_male, immigration_valid_female, immigration_invalid_male, immigration_invalid_female, accommodation_name, accommodation_number, accommodation_province_code, accommodation_district_code, accommodation_subdistrict_code, accommodation_location, accommodation_latitude, accommodation_longitude, accommodation_datetime, room_type, bathroom_count, bathroom_status, environment_status, created_at, updated_at) FROM '$$PATH$$/3569.dat';

--
-- Data for Name: line_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_groups (id, group_id, group_name, added_at, updated_at, last_message_at, is_active, member_count, notification_count) FROM stdin;
\.
COPY public.line_groups (id, group_id, group_name, added_at, updated_at, last_message_at, is_active, member_count, notification_count) FROM '$$PATH$$/3567.dat';

--
-- Data for Name: report_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_files (id, report_id, file_url, file_name, file_type, file_size, mime_type, uploaded_at) FROM stdin;
\.
COPY public.report_files (id, report_id, file_url, file_name, file_type, file_size, mime_type, uploaded_at) FROM '$$PATH$$/3573.dat';

--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, user_id, issue_type, sub_category_1, sub_category_2, sub_category_3, category_path, report_type, address, province_code, district_code, subdistrict_code, location_description, latitude, longitude, incident_datetime, consideration, other_results, files_count, liff_id, reported_at, updated_at, status) FROM stdin;
\.
COPY public.reports (id, user_id, issue_type, sub_category_1, sub_category_2, sub_category_3, category_path, report_type, address, province_code, district_code, subdistrict_code, location_description, latitude, longitude, incident_datetime, consideration, other_results, files_count, liff_id, reported_at, updated_at, status) FROM '$$PATH$$/3568.dat';

--
-- Data for Name: stateless_monks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stateless_monks (id, report_id, location_name, location_number, location_province_code, location_district_code, location_subdistrict_code, total_male, total_female, age_ranges, age_total, room_type, environment_status, immigration_valid_male, immigration_valid_female, immigration_invalid_male, immigration_invalid_female, nationalities, nationality_total, residence_no_citizenship_male, residence_no_citizenship_female, residence_no_citizenship_remark, stateless_male, stateless_female, stateless_remark, civil_status_other_male, civil_status_other_female, civil_status_other_remark, buddhist_male, buddhist_female, buddhist_remark, islam_male, islam_female, islam_remark, christian_male, christian_female, christian_remark, hindu_male, hindu_female, hindu_remark, judaism_male, judaism_female, judaism_remark, jainism_male, jainism_female, jainism_remark, sikhism_male, sikhism_female, sikhism_remark, taoism_confucianism_male, taoism_confucianism_female, taoism_confucianism_remark, religion_other_male, religion_other_female, religion_other_remark, created_at, updated_at) FROM stdin;
\.
COPY public.stateless_monks (id, report_id, location_name, location_number, location_province_code, location_district_code, location_subdistrict_code, total_male, total_female, age_ranges, age_total, room_type, environment_status, immigration_valid_male, immigration_valid_female, immigration_invalid_male, immigration_invalid_female, nationalities, nationality_total, residence_no_citizenship_male, residence_no_citizenship_female, residence_no_citizenship_remark, stateless_male, stateless_female, stateless_remark, civil_status_other_male, civil_status_other_female, civil_status_other_remark, buddhist_male, buddhist_female, buddhist_remark, islam_male, islam_female, islam_remark, christian_male, christian_female, christian_remark, hindu_male, hindu_female, hindu_remark, judaism_male, judaism_female, judaism_remark, jainism_male, jainism_female, jainism_remark, sikhism_male, sikhism_female, sikhism_remark, taoism_confucianism_male, taoism_confucianism_female, taoism_confucianism_remark, religion_other_male, religion_other_female, religion_other_remark, created_at, updated_at) FROM '$$PATH$$/3572.dat';

--
-- Data for Name: trafficking_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trafficking_details (id, report_id, training_round, children, youth, working_age, elderly, created_at, updated_at) FROM stdin;
\.
COPY public.trafficking_details (id, report_id, training_round, children, youth, working_age, elderly, created_at, updated_at) FROM '$$PATH$$/3571.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, line_user_id, line_display_name, line_picture_url, line_status_message, full_name, rank, "position", phone_number, line_id, organization_type, region, sub_region, unit_code, province_unit, full_unit_path, province_code, district_code, subdistrict_code, photo_url, photo_size, photo_type, photo_name, status, approved_by, approved_at, rejected_by, rejected_at, rejected_reason, liff_id, registered_at, updated_at, is_active, last_login_at) FROM stdin;
\.
COPY public.users (id, line_user_id, line_display_name, line_picture_url, line_status_message, full_name, rank, "position", phone_number, line_id, organization_type, region, sub_region, unit_code, province_unit, full_unit_path, province_code, district_code, subdistrict_code, photo_url, photo_size, photo_type, photo_name, status, approved_by, approved_at, rejected_by, rejected_at, rejected_reason, liff_id, registered_at, updated_at, is_active, last_login_at) FROM '$$PATH$$/3566.dat';

--
-- Name: inner_indicator inner_indicator_pkey; Type: CONSTRAINT; Schema: masterdata; Owner: -
--

ALTER TABLE ONLY masterdata.inner_indicator
    ADD CONSTRAINT inner_indicator_pkey PRIMARY KEY (province_code);


--
-- Name: immigration_border_area immigration_border_area_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.immigration_border_area
    ADD CONSTRAINT immigration_border_area_pkey PRIMARY KEY (id);


--
-- Name: immigration_border_area immigration_border_area_report_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.immigration_border_area
    ADD CONSTRAINT immigration_border_area_report_id_key UNIQUE (report_id);


--
-- Name: immigration_inner_area immigration_inner_area_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.immigration_inner_area
    ADD CONSTRAINT immigration_inner_area_pkey PRIMARY KEY (id);


--
-- Name: immigration_inner_area immigration_inner_area_report_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.immigration_inner_area
    ADD CONSTRAINT immigration_inner_area_report_id_key UNIQUE (report_id);


--
-- Name: line_groups line_groups_group_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_groups
    ADD CONSTRAINT line_groups_group_id_key UNIQUE (group_id);


--
-- Name: line_groups line_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_groups
    ADD CONSTRAINT line_groups_pkey PRIMARY KEY (id);


--
-- Name: report_files report_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_files
    ADD CONSTRAINT report_files_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: stateless_monks stateless_monks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stateless_monks
    ADD CONSTRAINT stateless_monks_pkey PRIMARY KEY (id);


--
-- Name: stateless_monks stateless_monks_report_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stateless_monks
    ADD CONSTRAINT stateless_monks_report_id_key UNIQUE (report_id);


--
-- Name: trafficking_details trafficking_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trafficking_details
    ADD CONSTRAINT trafficking_details_pkey PRIMARY KEY (id);


--
-- Name: trafficking_details trafficking_details_report_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trafficking_details
    ADD CONSTRAINT trafficking_details_report_id_key UNIQUE (report_id);


--
-- Name: users users_line_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_line_user_id_key UNIQUE (line_user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_files_report_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_files_report_id ON public.report_files USING btree (report_id);


--
-- Name: idx_immigration_border_report_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_immigration_border_report_id ON public.immigration_border_area USING btree (report_id);


--
-- Name: idx_immigration_inner_report_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_immigration_inner_report_id ON public.immigration_inner_area USING btree (report_id);


--
-- Name: idx_line_groups_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_groups_group_id ON public.line_groups USING btree (group_id);


--
-- Name: idx_line_groups_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_groups_is_active ON public.line_groups USING btree (is_active);


--
-- Name: idx_reports_issue_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_issue_type ON public.reports USING btree (issue_type);


--
-- Name: idx_reports_report_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_report_type ON public.reports USING btree (report_type);


--
-- Name: idx_reports_reported_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_reported_at ON public.reports USING btree (reported_at);


--
-- Name: idx_reports_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_user_id ON public.reports USING btree (user_id);


--
-- Name: idx_stateless_monks_report_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stateless_monks_report_id ON public.stateless_monks USING btree (report_id);


--
-- Name: idx_trafficking_report_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trafficking_report_id ON public.trafficking_details USING btree (report_id);


--
-- Name: idx_users_line_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_line_user_id ON public.users USING btree (line_user_id);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: immigration_inner_area trg_sync_reports_address; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_reports_address AFTER INSERT OR UPDATE OF accommodation_name, accommodation_province_code, accommodation_district_code, accommodation_subdistrict_code ON public.immigration_inner_area FOR EACH ROW EXECUTE FUNCTION masterdata.sync_reports_from_immi();


--
-- Name: immigration_border_area update_immigration_border_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_immigration_border_updated_at BEFORE UPDATE ON public.immigration_border_area FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: immigration_inner_area update_immigration_inner_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_immigration_inner_updated_at BEFORE UPDATE ON public.immigration_inner_area FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: line_groups update_line_groups_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_line_groups_updated_at BEFORE UPDATE ON public.line_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: reports update_reports_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_reports_updated_at BEFORE UPDATE ON public.reports FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: stateless_monks update_stateless_monks_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stateless_monks_updated_at BEFORE UPDATE ON public.stateless_monks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: trafficking_details update_trafficking_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_trafficking_updated_at BEFORE UPDATE ON public.trafficking_details FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: immigration_border_area immigration_border_area_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.immigration_border_area
    ADD CONSTRAINT immigration_border_area_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: immigration_inner_area immigration_inner_area_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.immigration_inner_area
    ADD CONSTRAINT immigration_inner_area_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: report_files report_files_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_files
    ADD CONSTRAINT report_files_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: reports reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stateless_monks stateless_monks_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stateless_monks
    ADD CONSTRAINT stateless_monks_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: trafficking_details trafficking_details_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trafficking_details
    ADD CONSTRAINT trafficking_details_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

