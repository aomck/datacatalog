--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.11 (Homebrew)
-- Dumped by pg_dump version 15.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE datacatalog;
--
-- Name: datacatalog; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE datacatalog WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


\connect datacatalog

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    icon text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: dataset_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset_types (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasets (
    id text NOT NULL,
    name text NOT NULL,
    detail text,
    unit_owner_id text NOT NULL,
    category_id text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone,
    metadata text,
    type_id text NOT NULL,
    security_level text
);


--
-- Name: request_dataset_approval_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_dataset_approval_files (
    id text NOT NULL,
    request_dataset_id text NOT NULL,
    file_path text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: request_datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_datasets (
    id text NOT NULL,
    request_id text NOT NULL,
    dataset_id text NOT NULL,
    approve_status text DEFAULT 'REQUESTED'::text NOT NULL,
    approved_by text,
    approved_at timestamp(3) without time zone,
    comment text
);


--
-- Name: request_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_files (
    id text NOT NULL,
    request_id text NOT NULL,
    file_path text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: request_service_approval_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_service_approval_files (
    id text NOT NULL,
    request_service_id text NOT NULL,
    file_path text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: request_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_services (
    id text NOT NULL,
    request_id text NOT NULL,
    service_id text NOT NULL,
    approve_status text DEFAULT 'REQUESTED'::text NOT NULL,
    approved_by text,
    approved_at timestamp(3) without time zone,
    comment text
);


--
-- Name: requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.requests (
    id text NOT NULL,
    requested_by text NOT NULL,
    name text NOT NULL,
    unit text NOT NULL,
    email text NOT NULL,
    tel text NOT NULL,
    detail text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id text NOT NULL,
    name text NOT NULL,
    detail text,
    dataset_id text NOT NULL,
    method text NOT NULL,
    api text NOT NULL,
    how_to text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: unit_owners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_owners (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    icon text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    user_id text NOT NULL,
    request_dataset_id text,
    request_service_id text,
    last_read_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: user_service_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_service_logs (
    id text NOT NULL,
    user_id text NOT NULL,
    service_id text NOT NULL,
    request_ip text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    token text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3728.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.categories (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3731.dat';

--
-- Data for Name: dataset_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataset_types (id, name, short_name, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.dataset_types (id, name, short_name, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3738.dat';

--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasets (id, name, detail, unit_owner_id, category_id, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt", metadata, type_id, security_level) FROM stdin;
\.
COPY public.datasets (id, name, detail, unit_owner_id, category_id, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt", metadata, type_id, security_level) FROM '$$PATH$$/3732.dat';

--
-- Data for Name: request_dataset_approval_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_dataset_approval_files (id, request_dataset_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.request_dataset_approval_files (id, request_dataset_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3739.dat';

--
-- Data for Name: request_datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_datasets (id, request_id, dataset_id, approve_status, approved_by, approved_at, comment) FROM stdin;
\.
COPY public.request_datasets (id, request_id, dataset_id, approve_status, approved_by, approved_at, comment) FROM '$$PATH$$/3735.dat';

--
-- Data for Name: request_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_files (id, request_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.request_files (id, request_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3737.dat';

--
-- Data for Name: request_service_approval_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_service_approval_files (id, request_service_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.request_service_approval_files (id, request_service_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3740.dat';

--
-- Data for Name: request_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_services (id, request_id, service_id, approve_status, approved_by, approved_at, comment) FROM stdin;
\.
COPY public.request_services (id, request_id, service_id, approve_status, approved_by, approved_at, comment) FROM '$$PATH$$/3736.dat';

--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.requests (id, requested_by, name, unit, email, tel, detail, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.requests (id, requested_by, name, unit, email, tel, detail, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3734.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, name, detail, dataset_id, method, api, how_to, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.services (id, name, detail, dataset_id, method, api, how_to, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3733.dat';

--
-- Data for Name: unit_owners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unit_owners (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.unit_owners (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3730.dat';

--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_notification_reads (id, user_id, request_dataset_id, request_service_id, last_read_at, created_at, updated_at) FROM stdin;
\.
COPY public.user_notification_reads (id, user_id, request_dataset_id, request_service_id, last_read_at, created_at, updated_at) FROM '$$PATH$$/3742.dat';

--
-- Data for Name: user_service_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_service_logs (id, user_id, service_id, request_ip, user_agent, created_at) FROM stdin;
\.
COPY public.user_service_logs (id, user_id, service_id, request_ip, user_agent, created_at) FROM '$$PATH$$/3741.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, token, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.users (id, token, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3729.dat';

--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: dataset_types dataset_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_types
    ADD CONSTRAINT dataset_types_pkey PRIMARY KEY (id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id);


--
-- Name: request_dataset_approval_files request_dataset_approval_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_dataset_approval_files
    ADD CONSTRAINT request_dataset_approval_files_pkey PRIMARY KEY (id);


--
-- Name: request_datasets request_datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_pkey PRIMARY KEY (id);


--
-- Name: request_files request_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_files
    ADD CONSTRAINT request_files_pkey PRIMARY KEY (id);


--
-- Name: request_service_approval_files request_service_approval_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_service_approval_files
    ADD CONSTRAINT request_service_approval_files_pkey PRIMARY KEY (id);


--
-- Name: request_services request_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_pkey PRIMARY KEY (id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: unit_owners unit_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_owners
    ADD CONSTRAINT unit_owners_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: user_service_logs user_service_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_service_logs
    ADD CONSTRAINT user_service_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_notification_reads_user_id_idx ON public.user_notification_reads USING btree (user_id);


--
-- Name: user_notification_reads_user_id_request_dataset_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_notification_reads_user_id_request_dataset_id_key ON public.user_notification_reads USING btree (user_id, request_dataset_id);


--
-- Name: user_notification_reads_user_id_request_service_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_notification_reads_user_id_request_service_id_key ON public.user_notification_reads USING btree (user_id, request_service_id);


--
-- Name: user_service_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_service_logs_created_at_idx ON public.user_service_logs USING btree (created_at);


--
-- Name: user_service_logs_service_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_service_logs_service_id_idx ON public.user_service_logs USING btree (service_id);


--
-- Name: user_service_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_service_logs_user_id_idx ON public.user_service_logs USING btree (user_id);


--
-- Name: users_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_token_key ON public.users USING btree (token);


--
-- Name: datasets datasets_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: datasets datasets_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.dataset_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: datasets datasets_unit_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_unit_owner_id_fkey FOREIGN KEY (unit_owner_id) REFERENCES public.unit_owners(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_dataset_approval_files request_dataset_approval_files_request_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_dataset_approval_files
    ADD CONSTRAINT request_dataset_approval_files_request_dataset_id_fkey FOREIGN KEY (request_dataset_id) REFERENCES public.request_datasets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_datasets request_datasets_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: request_datasets request_datasets_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_datasets request_datasets_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_files request_files_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_files
    ADD CONSTRAINT request_files_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_service_approval_files request_service_approval_files_request_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_service_approval_files
    ADD CONSTRAINT request_service_approval_files_request_service_id_fkey FOREIGN KEY (request_service_id) REFERENCES public.request_services(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_services request_services_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: request_services request_services_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_services request_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: requests requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: services services_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_service_logs user_service_logs_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_service_logs
    ADD CONSTRAINT user_service_logs_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_service_logs user_service_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_service_logs
    ADD CONSTRAINT user_service_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

