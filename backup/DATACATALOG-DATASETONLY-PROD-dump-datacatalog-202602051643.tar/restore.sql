--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.20 (Ubuntu 14.20-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 15.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE datacatalog;
--
-- Name: datacatalog; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE datacatalog WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


\connect datacatalog

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: active_duty_personnel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_duty_personnel (
    id bigint NOT NULL,
    citizen_id character varying(13) NOT NULL,
    rank character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date_be date,
    birth_date_ce date,
    age_year integer,
    nationality character varying(50),
    gender character varying(20),
    religion character varying(50),
    blood_type character varying(20),
    marital_status character varying(50),
    personnel_type character varying(50),
    personnel_no_10 character varying(10),
    military_force character varying(100),
    military_party character varying(100),
    military_branch character varying(100),
    military_category character varying(100),
    affiliation character varying(255),
    unit character varying(255),
    "position" character varying(255),
    rate character varying(100),
    home_address_no character varying(50),
    home_address_moo character varying(10),
    home_address_soi character varying(100),
    home_address_road character varying(100),
    home_province character varying(100),
    home_amphor character varying(100),
    home_tambon character varying(100),
    home_postcode character varying(10),
    education_level character varying(255),
    education_major character varying(255),
    special_skills text,
    contact_address_no character varying(50),
    contact_address_moo character varying(10),
    contact_address_soi character varying(100),
    contact_address_road character varying(100),
    contact_province character varying(100),
    contact_amphor character varying(100),
    contact_tambon character varying(100),
    contact_postcode character varying(10),
    phone_number character varying(20),
    email character varying(255),
    line_id character varying(100),
    facebook_url text,
    other_social_media text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


--
-- Name: active_duty_personnel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_duty_personnel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_duty_personnel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_duty_personnel_id_seq OWNED BY public.active_duty_personnel.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    icon text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone,
    "order" integer DEFAULT 0 NOT NULL
);


--
-- Name: dataset_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset_types (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasets (
    id text NOT NULL,
    name text NOT NULL,
    detail text,
    unit_owner_id text NOT NULL,
    category_id text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone,
    metadata text,
    type_id text NOT NULL,
    security_level text
);


--
-- Name: defense_civil_officer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.defense_civil_officer (
    id bigint NOT NULL,
    id_cardno character varying(13) NOT NULL,
    title character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    first_name_old character varying(100),
    last_name_old character varying(100),
    birth_date date,
    age integer,
    nationality character varying(50),
    gender character varying(20),
    religion character varying(50),
    blood_type character varying(20),
    marital_status character varying(50),
    level character varying(50),
    employee_id_10_digit character varying(10),
    department character varying(255),
    unit character varying(255),
    "position" character varying(255),
    rate character varying(100),
    reg_house_no character varying(50),
    reg_village_no character varying(10),
    reg_soi character varying(100),
    reg_road character varying(100),
    reg_province character varying(100),
    reg_district character varying(100),
    reg_subdistrict character varying(100),
    reg_postcode character varying(10),
    education_level character varying(255),
    major character varying(255),
    contact_house_no character varying(50),
    contact_village_no character varying(10),
    contact_soi character varying(100),
    contact_road character varying(100),
    contact_province character varying(100),
    contact_district character varying(100),
    contact_subdistrict character varying(100),
    contact_postcode character varying(10),
    phone character varying(20),
    email character varying(255),
    line_id character varying(100),
    facebook text,
    other_social_media text,
    xlock character varying(4),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: defense_civil_officer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.defense_civil_officer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: defense_civil_officer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.defense_civil_officer_id_seq OWNED BY public.defense_civil_officer.id;


--
-- Name: defense_civil_servant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.defense_civil_servant (
    id bigint NOT NULL,
    id_cardno character varying(13) NOT NULL,
    title character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date date,
    age integer,
    nationality character varying(50),
    gender character varying(20),
    religion character varying(50),
    blood_type character varying(20),
    marital_status character varying(50),
    employee_type character varying(100),
    employee_group character varying(100),
    employee_no_10 character varying(10),
    department character varying(255),
    unit character varying(255),
    "position" character varying(255),
    rate character varying(100),
    home_address_no character varying(50),
    home_address_moo character varying(10),
    home_address_soi character varying(100),
    home_address_road character varying(100),
    home_province character varying(100),
    home_amphoe character varying(100),
    home_tambon character varying(100),
    home_zipcode character varying(10),
    education_level character varying(255),
    major character varying(255),
    contact_address_no character varying(50),
    contact_address_moo character varying(10),
    contact_address_soi character varying(100),
    contact_address_road character varying(100),
    contact_province character varying(100),
    contact_amphoe character varying(100),
    contact_tambon character varying(100),
    contact_postcode character varying(10),
    phone character varying(20),
    email character varying(255),
    line_id character varying(100),
    facebook text,
    other_social_media text,
    xlock character varying(4),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


--
-- Name: defense_civil_servant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.defense_civil_servant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: defense_civil_servant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.defense_civil_servant_id_seq OWNED BY public.defense_civil_servant.id;


--
-- Name: employee_contract; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_contract (
    id bigint NOT NULL,
    id_cardno character varying(13) NOT NULL,
    title character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date date,
    age integer,
    nationality character varying(50),
    gender character varying(20),
    religion character varying(50),
    blood_type character varying(20),
    marital_status character varying(50),
    employee_type character varying(100),
    employee_no_10 character varying(10),
    department character varying(255),
    unit character varying(255),
    "position" character varying(255),
    rate character varying(100),
    home_address_no character varying(50),
    home_address_moo character varying(10),
    home_address_soi character varying(100),
    home_address_road character varying(100),
    home_province character varying(100),
    home_amphoe character varying(100),
    home_tambon character varying(100),
    home_zipcode character varying(10),
    education_level character varying(255),
    major character varying(255),
    contact_address_no character varying(50),
    contact_address_moo character varying(10),
    contact_address_soi character varying(100),
    contact_address_road character varying(100),
    contact_province character varying(100),
    contact_amphoe character varying(100),
    contact_tambon character varying(100),
    contact_postcode character varying(10),
    phone character varying(20),
    email character varying(255),
    line_id character varying(100),
    facebook text,
    other_social_media text,
    xlock character varying(4),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: employee_contract_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_contract_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_contract_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_contract_id_seq OWNED BY public.employee_contract.id;


--
-- Name: enlisted_personnel_type_2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enlisted_personnel_type_2 (
    id bigint NOT NULL,
    id_cardno character varying(13) NOT NULL,
    title character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date date,
    age_year integer,
    religion character varying(50),
    blood_type character varying(10),
    weight_kg numeric(5,2),
    height_cm numeric(5,2),
    marital_status character varying(50),
    military_origin text,
    military_address_no character varying(50),
    military_address_moo character varying(10),
    military_address_soi character varying(100),
    military_address_road character varying(100),
    military_province character varying(100),
    military_amphoe character varying(100),
    military_tambon character varying(100),
    conscription_year_be integer,
    sd43_document_no character varying(50),
    reserve_class character varying(50),
    home_address_text text,
    home_address_no character varying(50),
    home_address_moo character varying(10),
    home_address_soi character varying(100),
    home_address_road character varying(100),
    home_province character varying(100),
    home_amphoe character varying(100),
    home_tambon character varying(100),
    home_postcode character varying(10),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: enlisted_personnel_type_2_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enlisted_personnel_type_2_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enlisted_personnel_type_2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enlisted_personnel_type_2_id_seq OWNED BY public.enlisted_personnel_type_2.id;


--
-- Name: female_reserve_soldier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.female_reserve_soldier (
    id bigint NOT NULL,
    id_cardno character varying(13) NOT NULL,
    rank character varying(50),
    type character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date date,
    age_year integer,
    religion character varying(50),
    blood_type character varying(5),
    weight_kg numeric(5,2),
    height_cm numeric(5,2),
    marital_status character varying(50),
    origin character varying(100),
    military_force character varying(100),
    military_party character varying(100),
    military_branch character varying(100),
    military_category character varying(100),
    active_service_info text,
    last_affiliation character varying(255),
    last_position character varying(100),
    home_address_text text,
    home_address_no character varying(50),
    home_address_moo character varying(10),
    home_address_soi character varying(100),
    home_address_road character varying(100),
    home_province character varying(100),
    home_amphoe character varying(100),
    home_tambon character varying(100),
    home_postcode character varying(10),
    education_info text,
    education_level character varying(100),
    education_major character varying(100),
    special_skills text,
    occupation_info text,
    current_occupation character varying(100),
    workplace_position character varying(100),
    workplace_name character varying(255),
    workplace_address_no character varying(50),
    workplace_address_moo character varying(10),
    workplace_address_soi character varying(100),
    workplace_address_road character varying(100),
    workplace_province character varying(100),
    workplace_amphoe character varying(100),
    workplace_tambon character varying(100),
    workplace_postcode character varying(10),
    workplace_phone character varying(20),
    contact_address_text text,
    contact_address_no character varying(50),
    contact_address_moo character varying(10),
    contact_address_soi character varying(100),
    contact_address_road character varying(100),
    contact_province character varying(100),
    contact_amphoe character varying(100),
    contact_tambon character varying(100),
    contact_postcode character varying(10),
    phone_number character varying(20),
    email character varying(255),
    line_id character varying(100),
    facebook_url character varying(255),
    other_social_media character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


--
-- Name: female_reserve_soldier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.female_reserve_soldier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: female_reserve_soldier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.female_reserve_soldier_id_seq OWNED BY public.female_reserve_soldier.id;


--
-- Name: government_employee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.government_employee (
    id bigint NOT NULL,
    id_cardno character varying(13) NOT NULL,
    title character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date date,
    age integer,
    nationality character varying(50),
    gender character varying(20),
    religion character varying(50),
    blood_type character varying(20),
    marital_status character varying(50),
    employee_type character varying(100),
    employee_group character varying(100),
    employee_no_10 character varying(10),
    department character varying(255),
    unit character varying(255),
    "position" character varying(255),
    rate character varying(100),
    home_address_no character varying(50),
    home_address_moo character varying(10),
    home_address_soi character varying(100),
    home_address_road character varying(100),
    home_province character varying(100),
    home_amphoe character varying(100),
    home_tambon character varying(100),
    home_zipcode character varying(10),
    education_level character varying(255),
    major character varying(255),
    contact_address_no character varying(50),
    contact_address_moo character varying(10),
    contact_address_soi character varying(100),
    contact_address_road character varying(100),
    contact_province character varying(100),
    contact_amphoe character varying(100),
    contact_tambon character varying(100),
    contact_postcode character varying(10),
    phone_number character varying(20),
    email character varying(255),
    line_id character varying(100),
    facebook_url text,
    other_social_media text,
    xlock character varying(4),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


--
-- Name: government_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.government_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: government_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.government_employee_id_seq OWNED BY public.government_employee.id;


--
-- Name: military_personnel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.military_personnel (
    id integer NOT NULL,
    citizen_id character varying(20),
    title character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date_be date,
    birth_date_ce date,
    age_year integer,
    nationality character varying(50),
    religion character varying(50),
    basic_education character varying(255),
    occupation character varying(255),
    special_skills text,
    notable_mark text,
    home_address_no character varying(50),
    home_address_moo character varying(10),
    home_address_soi character varying(100),
    home_address_road character varying(100),
    home_province character varying(100),
    home_amphor character varying(100),
    home_tambon character varying(100),
    home_postcode character varying(10),
    phone_number character varying(20),
    father_citizen_id character varying(20),
    father_title character varying(50),
    father_first_name character varying(100),
    father_last_name character varying(100),
    father_nationality character varying(50),
    mother_citizen_id character varying(20),
    mother_first_name character varying(100),
    mother_last_name character varying(100),
    mother_nationality character varying(50),
    military_domicile_type character varying(100),
    military_address_no character varying(50),
    military_address_moo character varying(10),
    military_address_soi character varying(100),
    military_address_road character varying(100),
    military_province character varying(100),
    military_amphor character varying(100),
    military_tambon character varying(100),
    sd9_document_no character varying(50),
    sd9_received_date date,
    sd9_enroll_year integer,
    sd9_enroll_date date,
    conscription_result_status character varying(100),
    sd43_issue_no character varying(50),
    sd43_document_no character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


--
-- Name: military_personnel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.military_personnel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: military_personnel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.military_personnel_id_seq OWNED BY public.military_personnel.id;


--
-- Name: military_student; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.military_student (
    id bigint NOT NULL,
    id_cardno character varying(13) NOT NULL,
    title character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    previous_first_name character varying(100),
    previous_last_name character varying(100),
    birth_date date,
    age_year integer,
    gender character varying(20),
    nationality character varying(50),
    religion character varying(50),
    ror_dor_student_code character varying(50),
    ror_dor_enroll_date date,
    ror_dor_enroll_academy integer,
    military_force character varying(100),
    status character varying(50),
    study_year character varying(50),
    institution_name character varying(255),
    institution_address_text text,
    institution_address_no character varying(50),
    institution_address_moo character varying(10),
    institution_address_soi character varying(100),
    institution_address_road character varying(100),
    institution_province character varying(100),
    institution_district character varying(100),
    institution_subdistrict character varying(100),
    institution_postcode character varying(10),
    rd25_document_no character varying(50),
    current_academic_year integer,
    transferred_institution_name character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


--
-- Name: military_student_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.military_student_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: military_student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.military_student_id_seq OWNED BY public.military_student.id;


--
-- Name: request_dataset_approval_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_dataset_approval_files (
    id text NOT NULL,
    request_dataset_id text NOT NULL,
    file_path text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: request_datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_datasets (
    id text NOT NULL,
    request_id text NOT NULL,
    dataset_id text NOT NULL,
    approve_status text DEFAULT 'REQUESTED'::text NOT NULL,
    approved_by text,
    approved_at timestamp(3) without time zone,
    comment text
);


--
-- Name: request_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_files (
    id text NOT NULL,
    request_id text NOT NULL,
    file_path text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: request_service_approval_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_service_approval_files (
    id text NOT NULL,
    request_service_id text NOT NULL,
    file_path text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: request_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_services (
    id text NOT NULL,
    request_id text NOT NULL,
    service_id text NOT NULL,
    approve_status text DEFAULT 'REQUESTED'::text NOT NULL,
    approved_by text,
    approved_at timestamp(3) without time zone,
    comment text
);


--
-- Name: requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.requests (
    id text NOT NULL,
    requested_by text NOT NULL,
    name text NOT NULL,
    unit text NOT NULL,
    email text NOT NULL,
    tel text NOT NULL,
    detail text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id text NOT NULL,
    name text NOT NULL,
    detail text,
    dataset_id text NOT NULL,
    method text NOT NULL,
    api text NOT NULL,
    how_to text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: unit_owners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_owners (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    icon text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    user_id text NOT NULL,
    request_dataset_id text,
    request_service_id text,
    last_read_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: user_service_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_service_logs (
    id text NOT NULL,
    user_id text NOT NULL,
    service_id text NOT NULL,
    request_ip text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    token text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedBy" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedBy" text,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: active_duty_personnel id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_duty_personnel ALTER COLUMN id SET DEFAULT nextval('public.active_duty_personnel_id_seq'::regclass);


--
-- Name: defense_civil_officer id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defense_civil_officer ALTER COLUMN id SET DEFAULT nextval('public.defense_civil_officer_id_seq'::regclass);


--
-- Name: defense_civil_servant id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defense_civil_servant ALTER COLUMN id SET DEFAULT nextval('public.defense_civil_servant_id_seq'::regclass);


--
-- Name: employee_contract id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contract ALTER COLUMN id SET DEFAULT nextval('public.employee_contract_id_seq'::regclass);


--
-- Name: enlisted_personnel_type_2 id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enlisted_personnel_type_2 ALTER COLUMN id SET DEFAULT nextval('public.enlisted_personnel_type_2_id_seq'::regclass);


--
-- Name: female_reserve_soldier id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.female_reserve_soldier ALTER COLUMN id SET DEFAULT nextval('public.female_reserve_soldier_id_seq'::regclass);


--
-- Name: government_employee id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.government_employee ALTER COLUMN id SET DEFAULT nextval('public.government_employee_id_seq'::regclass);


--
-- Name: military_personnel id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.military_personnel ALTER COLUMN id SET DEFAULT nextval('public.military_personnel_id_seq'::regclass);


--
-- Name: military_student id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.military_student ALTER COLUMN id SET DEFAULT nextval('public.military_student_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3520.dat';

--
-- Data for Name: active_duty_personnel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.active_duty_personnel (id, citizen_id, rank, first_name, last_name, previous_first_name, previous_last_name, birth_date_be, birth_date_ce, age_year, nationality, gender, religion, blood_type, marital_status, personnel_type, personnel_no_10, military_force, military_party, military_branch, military_category, affiliation, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphor, home_tambon, home_postcode, education_level, education_major, special_skills, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphor, contact_tambon, contact_postcode, phone_number, email, line_id, facebook_url, other_social_media, created_at, updated_at) FROM stdin;
\.
COPY public.active_duty_personnel (id, citizen_id, rank, first_name, last_name, previous_first_name, previous_last_name, birth_date_be, birth_date_ce, age_year, nationality, gender, religion, blood_type, marital_status, personnel_type, personnel_no_10, military_force, military_party, military_branch, military_category, affiliation, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphor, home_tambon, home_postcode, education_level, education_major, special_skills, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphor, contact_tambon, contact_postcode, phone_number, email, line_id, facebook_url, other_social_media, created_at, updated_at) FROM '$$PATH$$/3544.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt", "order") FROM stdin;
\.
COPY public.categories (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt", "order") FROM '$$PATH$$/3521.dat';

--
-- Data for Name: dataset_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataset_types (id, name, short_name, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.dataset_types (id, name, short_name, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3522.dat';

--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasets (id, name, detail, unit_owner_id, category_id, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt", metadata, type_id, security_level) FROM stdin;
\.
COPY public.datasets (id, name, detail, unit_owner_id, category_id, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt", metadata, type_id, security_level) FROM '$$PATH$$/3523.dat';

--
-- Data for Name: defense_civil_officer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.defense_civil_officer (id, id_cardno, title, first_name, last_name, first_name_old, last_name_old, birth_date, age, nationality, gender, religion, blood_type, marital_status, level, employee_id_10_digit, department, unit, "position", rate, reg_house_no, reg_village_no, reg_soi, reg_road, reg_province, reg_district, reg_subdistrict, reg_postcode, education_level, major, contact_house_no, contact_village_no, contact_soi, contact_road, contact_province, contact_district, contact_subdistrict, contact_postcode, phone, email, line_id, facebook, other_social_media, xlock, created_at, updated_at) FROM stdin;
\.
COPY public.defense_civil_officer (id, id_cardno, title, first_name, last_name, first_name_old, last_name_old, birth_date, age, nationality, gender, religion, blood_type, marital_status, level, employee_id_10_digit, department, unit, "position", rate, reg_house_no, reg_village_no, reg_soi, reg_road, reg_province, reg_district, reg_subdistrict, reg_postcode, education_level, major, contact_house_no, contact_village_no, contact_soi, contact_road, contact_province, contact_district, contact_subdistrict, contact_postcode, phone, email, line_id, facebook, other_social_media, xlock, created_at, updated_at) FROM '$$PATH$$/3552.dat';

--
-- Data for Name: defense_civil_servant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.defense_civil_servant (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age, nationality, gender, religion, blood_type, marital_status, employee_type, employee_group, employee_no_10, department, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_zipcode, education_level, major, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone, email, line_id, facebook, other_social_media, xlock, created_at, updated_at) FROM stdin;
\.
COPY public.defense_civil_servant (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age, nationality, gender, religion, blood_type, marital_status, employee_type, employee_group, employee_no_10, department, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_zipcode, education_level, major, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone, email, line_id, facebook, other_social_media, xlock, created_at, updated_at) FROM '$$PATH$$/3550.dat';

--
-- Data for Name: employee_contract; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_contract (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age, nationality, gender, religion, blood_type, marital_status, employee_type, employee_no_10, department, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_zipcode, education_level, major, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone, email, line_id, facebook, other_social_media, xlock, created_at, updated_at) FROM stdin;
\.
COPY public.employee_contract (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age, nationality, gender, religion, blood_type, marital_status, employee_type, employee_no_10, department, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_zipcode, education_level, major, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone, email, line_id, facebook, other_social_media, xlock, created_at, updated_at) FROM '$$PATH$$/3548.dat';

--
-- Data for Name: enlisted_personnel_type_2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enlisted_personnel_type_2 (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age_year, religion, blood_type, weight_kg, height_cm, marital_status, military_origin, military_address_no, military_address_moo, military_address_soi, military_address_road, military_province, military_amphoe, military_tambon, conscription_year_be, sd43_document_no, reserve_class, home_address_text, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_postcode, created_at, updated_at) FROM stdin;
\.
COPY public.enlisted_personnel_type_2 (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age_year, religion, blood_type, weight_kg, height_cm, marital_status, military_origin, military_address_no, military_address_moo, military_address_soi, military_address_road, military_province, military_amphoe, military_tambon, conscription_year_be, sd43_document_no, reserve_class, home_address_text, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_postcode, created_at, updated_at) FROM '$$PATH$$/3536.dat';

--
-- Data for Name: female_reserve_soldier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.female_reserve_soldier (id, id_cardno, rank, type, first_name, last_name, previous_first_name, previous_last_name, birth_date, age_year, religion, blood_type, weight_kg, height_cm, marital_status, origin, military_force, military_party, military_branch, military_category, active_service_info, last_affiliation, last_position, home_address_text, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_postcode, education_info, education_level, education_major, special_skills, occupation_info, current_occupation, workplace_position, workplace_name, workplace_address_no, workplace_address_moo, workplace_address_soi, workplace_address_road, workplace_province, workplace_amphoe, workplace_tambon, workplace_postcode, workplace_phone, contact_address_text, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone_number, email, line_id, facebook_url, other_social_media, created_at, updated_at) FROM stdin;
\.
COPY public.female_reserve_soldier (id, id_cardno, rank, type, first_name, last_name, previous_first_name, previous_last_name, birth_date, age_year, religion, blood_type, weight_kg, height_cm, marital_status, origin, military_force, military_party, military_branch, military_category, active_service_info, last_affiliation, last_position, home_address_text, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_postcode, education_info, education_level, education_major, special_skills, occupation_info, current_occupation, workplace_position, workplace_name, workplace_address_no, workplace_address_moo, workplace_address_soi, workplace_address_road, workplace_province, workplace_amphoe, workplace_tambon, workplace_postcode, workplace_phone, contact_address_text, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone_number, email, line_id, facebook_url, other_social_media, created_at, updated_at) FROM '$$PATH$$/3540.dat';

--
-- Data for Name: government_employee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.government_employee (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age, nationality, gender, religion, blood_type, marital_status, employee_type, employee_group, employee_no_10, department, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_zipcode, education_level, major, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone_number, email, line_id, facebook_url, other_social_media, xlock, created_at, updated_at) FROM stdin;
\.
COPY public.government_employee (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age, nationality, gender, religion, blood_type, marital_status, employee_type, employee_group, employee_no_10, department, unit, "position", rate, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphoe, home_tambon, home_zipcode, education_level, major, contact_address_no, contact_address_moo, contact_address_soi, contact_address_road, contact_province, contact_amphoe, contact_tambon, contact_postcode, phone_number, email, line_id, facebook_url, other_social_media, xlock, created_at, updated_at) FROM '$$PATH$$/3546.dat';

--
-- Data for Name: military_personnel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.military_personnel (id, citizen_id, title, first_name, last_name, previous_first_name, previous_last_name, birth_date_be, birth_date_ce, age_year, nationality, religion, basic_education, occupation, special_skills, notable_mark, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphor, home_tambon, home_postcode, phone_number, father_citizen_id, father_title, father_first_name, father_last_name, father_nationality, mother_citizen_id, mother_first_name, mother_last_name, mother_nationality, military_domicile_type, military_address_no, military_address_moo, military_address_soi, military_address_road, military_province, military_amphor, military_tambon, sd9_document_no, sd9_received_date, sd9_enroll_year, sd9_enroll_date, conscription_result_status, sd43_issue_no, sd43_document_no, created_at, updated_at) FROM stdin;
\.
COPY public.military_personnel (id, citizen_id, title, first_name, last_name, previous_first_name, previous_last_name, birth_date_be, birth_date_ce, age_year, nationality, religion, basic_education, occupation, special_skills, notable_mark, home_address_no, home_address_moo, home_address_soi, home_address_road, home_province, home_amphor, home_tambon, home_postcode, phone_number, father_citizen_id, father_title, father_first_name, father_last_name, father_nationality, mother_citizen_id, mother_first_name, mother_last_name, mother_nationality, military_domicile_type, military_address_no, military_address_moo, military_address_soi, military_address_road, military_province, military_amphor, military_tambon, sd9_document_no, sd9_received_date, sd9_enroll_year, sd9_enroll_date, conscription_result_status, sd43_issue_no, sd43_document_no, created_at, updated_at) FROM '$$PATH$$/3542.dat';

--
-- Data for Name: military_student; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.military_student (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age_year, gender, nationality, religion, ror_dor_student_code, ror_dor_enroll_date, ror_dor_enroll_academy, military_force, status, study_year, institution_name, institution_address_text, institution_address_no, institution_address_moo, institution_address_soi, institution_address_road, institution_province, institution_district, institution_subdistrict, institution_postcode, rd25_document_no, current_academic_year, transferred_institution_name, created_at, updated_at) FROM stdin;
\.
COPY public.military_student (id, id_cardno, title, first_name, last_name, previous_first_name, previous_last_name, birth_date, age_year, gender, nationality, religion, ror_dor_student_code, ror_dor_enroll_date, ror_dor_enroll_academy, military_force, status, study_year, institution_name, institution_address_text, institution_address_no, institution_address_moo, institution_address_soi, institution_address_road, institution_province, institution_district, institution_subdistrict, institution_postcode, rd25_document_no, current_academic_year, transferred_institution_name, created_at, updated_at) FROM '$$PATH$$/3538.dat';

--
-- Data for Name: request_dataset_approval_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_dataset_approval_files (id, request_dataset_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.request_dataset_approval_files (id, request_dataset_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3524.dat';

--
-- Data for Name: request_datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_datasets (id, request_id, dataset_id, approve_status, approved_by, approved_at, comment) FROM stdin;
\.
COPY public.request_datasets (id, request_id, dataset_id, approve_status, approved_by, approved_at, comment) FROM '$$PATH$$/3525.dat';

--
-- Data for Name: request_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_files (id, request_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.request_files (id, request_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3526.dat';

--
-- Data for Name: request_service_approval_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_service_approval_files (id, request_service_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.request_service_approval_files (id, request_service_id, file_path, file_name, file_type, file_size, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3527.dat';

--
-- Data for Name: request_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.request_services (id, request_id, service_id, approve_status, approved_by, approved_at, comment) FROM stdin;
\.
COPY public.request_services (id, request_id, service_id, approve_status, approved_by, approved_at, comment) FROM '$$PATH$$/3528.dat';

--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.requests (id, requested_by, name, unit, email, tel, detail, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.requests (id, requested_by, name, unit, email, tel, detail, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3529.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, name, detail, dataset_id, method, api, how_to, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.services (id, name, detail, dataset_id, method, api, how_to, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3530.dat';

--
-- Data for Name: unit_owners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unit_owners (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.unit_owners (id, name, short_name, icon, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3531.dat';

--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_notification_reads (id, user_id, request_dataset_id, request_service_id, last_read_at, created_at, updated_at) FROM stdin;
\.
COPY public.user_notification_reads (id, user_id, request_dataset_id, request_service_id, last_read_at, created_at, updated_at) FROM '$$PATH$$/3532.dat';

--
-- Data for Name: user_service_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_service_logs (id, user_id, service_id, request_ip, user_agent, created_at) FROM stdin;
\.
COPY public.user_service_logs (id, user_id, service_id, request_ip, user_agent, created_at) FROM '$$PATH$$/3533.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, token, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM stdin;
\.
COPY public.users (id, token, "createdBy", "createdAt", "updatedBy", "updatedAt", "deletedBy", "deletedAt") FROM '$$PATH$$/3534.dat';

--
-- Name: active_duty_personnel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.active_duty_personnel_id_seq', 1, false);


--
-- Name: defense_civil_officer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.defense_civil_officer_id_seq', 1, false);


--
-- Name: defense_civil_servant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.defense_civil_servant_id_seq', 1, false);


--
-- Name: employee_contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_contract_id_seq', 1, false);


--
-- Name: enlisted_personnel_type_2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enlisted_personnel_type_2_id_seq', 1, false);


--
-- Name: female_reserve_soldier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.female_reserve_soldier_id_seq', 1, false);


--
-- Name: government_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.government_employee_id_seq', 1, false);


--
-- Name: military_personnel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.military_personnel_id_seq', 1, false);


--
-- Name: military_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.military_student_id_seq', 1, false);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: active_duty_personnel active_duty_personnel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_duty_personnel
    ADD CONSTRAINT active_duty_personnel_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: dataset_types dataset_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_types
    ADD CONSTRAINT dataset_types_pkey PRIMARY KEY (id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id);


--
-- Name: defense_civil_officer defense_civil_officer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defense_civil_officer
    ADD CONSTRAINT defense_civil_officer_pkey PRIMARY KEY (id);


--
-- Name: defense_civil_servant defense_civil_servant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defense_civil_servant
    ADD CONSTRAINT defense_civil_servant_pkey PRIMARY KEY (id);


--
-- Name: employee_contract employee_contract_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contract
    ADD CONSTRAINT employee_contract_pkey PRIMARY KEY (id);


--
-- Name: enlisted_personnel_type_2 enlisted_personnel_type_2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enlisted_personnel_type_2
    ADD CONSTRAINT enlisted_personnel_type_2_pkey PRIMARY KEY (id);


--
-- Name: female_reserve_soldier female_reserve_soldier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.female_reserve_soldier
    ADD CONSTRAINT female_reserve_soldier_pkey PRIMARY KEY (id);


--
-- Name: government_employee government_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.government_employee
    ADD CONSTRAINT government_employee_pkey PRIMARY KEY (id);


--
-- Name: military_personnel military_personnel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.military_personnel
    ADD CONSTRAINT military_personnel_pkey PRIMARY KEY (id);


--
-- Name: military_student military_student_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.military_student
    ADD CONSTRAINT military_student_pkey PRIMARY KEY (id);


--
-- Name: request_dataset_approval_files request_dataset_approval_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_dataset_approval_files
    ADD CONSTRAINT request_dataset_approval_files_pkey PRIMARY KEY (id);


--
-- Name: request_datasets request_datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_pkey PRIMARY KEY (id);


--
-- Name: request_files request_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_files
    ADD CONSTRAINT request_files_pkey PRIMARY KEY (id);


--
-- Name: request_service_approval_files request_service_approval_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_service_approval_files
    ADD CONSTRAINT request_service_approval_files_pkey PRIMARY KEY (id);


--
-- Name: request_services request_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_pkey PRIMARY KEY (id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: unit_owners unit_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_owners
    ADD CONSTRAINT unit_owners_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: user_service_logs user_service_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_service_logs
    ADD CONSTRAINT user_service_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_notification_reads_user_id_idx ON public.user_notification_reads USING btree (user_id);


--
-- Name: user_notification_reads_user_id_request_dataset_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_notification_reads_user_id_request_dataset_id_key ON public.user_notification_reads USING btree (user_id, request_dataset_id);


--
-- Name: user_notification_reads_user_id_request_service_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_notification_reads_user_id_request_service_id_key ON public.user_notification_reads USING btree (user_id, request_service_id);


--
-- Name: user_service_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_service_logs_created_at_idx ON public.user_service_logs USING btree (created_at);


--
-- Name: user_service_logs_service_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_service_logs_service_id_idx ON public.user_service_logs USING btree (service_id);


--
-- Name: user_service_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_service_logs_user_id_idx ON public.user_service_logs USING btree (user_id);


--
-- Name: users_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_token_key ON public.users USING btree (token);


--
-- Name: datasets datasets_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: datasets datasets_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.dataset_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: datasets datasets_unit_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_unit_owner_id_fkey FOREIGN KEY (unit_owner_id) REFERENCES public.unit_owners(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_dataset_approval_files request_dataset_approval_files_request_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_dataset_approval_files
    ADD CONSTRAINT request_dataset_approval_files_request_dataset_id_fkey FOREIGN KEY (request_dataset_id) REFERENCES public.request_datasets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: request_datasets request_datasets_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: request_datasets request_datasets_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: request_datasets request_datasets_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_datasets
    ADD CONSTRAINT request_datasets_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: request_files request_files_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_files
    ADD CONSTRAINT request_files_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: request_service_approval_files request_service_approval_files_request_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_service_approval_files
    ADD CONSTRAINT request_service_approval_files_request_service_id_fkey FOREIGN KEY (request_service_id) REFERENCES public.request_services(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: request_services request_services_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: request_services request_services_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: request_services request_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_services
    ADD CONSTRAINT request_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: requests requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: services services_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_service_logs user_service_logs_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_service_logs
    ADD CONSTRAINT user_service_logs_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_service_logs user_service_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_service_logs
    ADD CONSTRAINT user_service_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

